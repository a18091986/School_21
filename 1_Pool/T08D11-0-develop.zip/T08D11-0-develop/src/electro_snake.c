#include <stdio.h>
#include <stdlib.h>

/*
    1 6 7
    2 5 8
    3 4 9
*/
void sort_vertical(int **matrix, int row, int col, int **result_matrix);

/*
    1 2 3
    6 5 4
    7 8 9
*/
void sort_horizontal(int **matrix, int row, int col, int **result_matrix);
int input(int **matrix, int *row, int *col);
void output(int **matrix, int n, int m);
void sort(int *a, int n);

int main() {
  int **matrix, **result;
  int row, col;

  if ((scanf("%d%d", &row, &col) == 2) && (row > 0) && (col > 0)) {
    matrix = malloc(row * sizeof(int *));
    result = malloc(row * sizeof(int *));
    if ((matrix != NULL) && (result != NULL)) {
      for (int i = 0; i < row; i++) {
        matrix[i] = malloc(col * sizeof(int));
        result[i] = malloc(col * sizeof(int));
      }
      for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++) {
          matrix[i][j] = 0;
          result[i][j] = 0;
        }
      if (input(matrix, &row, &col) == 1) {
        sort_vertical(matrix, row, col, result);
        output(result, row, col);
        printf("\n");
        sort_horizontal(matrix, row, col, result);
        output(result, row, col);
      } else {
        printf("n/a");
      }
    } else {
      printf("n/a");
    }

    for (int i = 0; i < row; i++) {
      free(matrix[i]);
      free(result[i]);
    }

    free(matrix);
    free(result);
    return 0;
  } else {
    printf("n/a");
  }
}

int input(int **matrix, int *row, int *col) {
  int success = 1;
  for (int i = 0; i < *row; i++)
    for (int j = 0; j < *col; j++)
      (scanf("%d", &matrix[i][j]) == 1) ? (success = 1) : (success = 0);

  /*if (success == 1) {
    output(matrix, *row, *col);
  }*/

  return success;
}

void sort_vertical(int **matrix, int row, int col, int **result) {
  int *a;
  a = (int *)malloc(row * col * sizeof(int));

  for (int i = 0; i < row; i++)
    for (int j = 0; j < col; j++)
      a[row * i + j] = matrix[i][j];

  sort(a, row * col);

  int k = 0;
  for (int i = 0; i < col; i++) {
    if (i % 2 == 0) {
      for (int j = 0; j < row; j++) {
        result[j][i] = a[k];
        k++;
      }
    } else {
      for (int j = row - 1; j >= 0; j--) {
        result[j][i] = a[k];
        k++;
      }
    }
  }
  printf("\n");
  free(a);
}

void sort_horizontal(int **matrix, int row, int col, int **result) {
  int *a;
  a = (int *)malloc(row * col * sizeof(int));
  for (int i = 0; i < row; i++)
    for (int j = 0; j < col; j++)
      a[row * i + j] = matrix[i][j];

  sort(a, row * col);

  int k = 0;
  for (int i = 0; i < row; i++) {
    if (i % 2 == 0) {
      for (int j = 0; j < col; j++) {
        result[i][j] = a[k];
        k++;
      }
    } else {
      for (int j = col - 1; j >= 0; j--) {
        result[i][j] = a[k];
        k++;
      }
    }
  }
  printf("\n");
  free(a);
}

void output(int **matrix, int row, int col) {
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++)
      (j != col - 1) ? (printf("%d ", matrix[i][j]))
                     : (printf("%d", matrix[i][j]));
    if (i != row - 1) {
      printf("\n");
    }
  }
}

void sort(int *a, int n) {
  int temp;
  for (int i = 0; i < n; i++) {
    for (int *p = a; p < &a[n] - 1; p++) {
      if (*p > *(p + 1)) {
        temp = *p;
        *p = *(p + 1);
        *(p + 1) = temp;
      }
    }
  }
}
