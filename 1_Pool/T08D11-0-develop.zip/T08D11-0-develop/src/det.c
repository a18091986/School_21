#include <stdio.h>
#include <stdlib.h>

int input(int **matrix, int *n);
void output(int **matrix, int n);
double det(int **matrix, int n);
int **matr(int **a, int n, int x);

int main() {
  int **matrix;
  int n;

  if ((scanf("%d", &n) == 1) && (n > 0)) {
    matrix = malloc(n * sizeof(int *));

    if ((matrix != NULL)) {
      for (int i = 0; i < n; i++) {
        matrix[i] = malloc(n * sizeof(int));
      }
      for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
          matrix[i][j] = 0;
        }

      if (input(matrix, &n) == 1) {
        // output(matrix, n);
        printf("\n%lf", det(matrix, n));
      } else {
        printf("n/a");
      }
    } else {
      printf("n/a");
    }

    for (int i = 0; i < n; i++) {
      free(matrix[i]);
    }

    free(matrix);
    return 0;
  } else {
    printf("n/a");
  }
}

int input(int **matrix, int *n) {
  int success = 1;
  for (int i = 0; i < *n; i++)
    for (int j = 0; j < *n; j++)
      (scanf("%d", &matrix[i][j]) == 1) ? (success = 1) : (success = 0);

  return success;
}

double det(int **matrix, int n) {
  if (n == 1)
    return (double)matrix[0][0];
  if (n == 2)
    return (double)(matrix[1][1] * matrix[0][0]) -
           (matrix[0][1] * matrix[1][0]);
  int min = 0;
  int sig = 1;
  for (int i = 0; i < n; i++) {
    min +=
        (sig * (double)matrix[0][i] * (double)det(matr(matrix, n, i), n - 1));
    sig *= -1;
  }
  return min;
}

void output(int **matrix, int n) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++)
      (j != n - 1) ? (printf("%d ", matrix[i][j]))
                   : (printf("%d", matrix[i][j]));
    if (i != n - 1) {
      printf("\n");
    }
  }
}

int **matr(int **a, int n, int x) {
  int **res = (int **)malloc((n - 1) * sizeof(int *));
  for (int i = 0; i < n - 1; i++)
    res[i] = (int *)malloc((n - 1) * sizeof(int));
  for (int i; i < n; i++)
    for (int j = 0, k = 0; j < n; j++, k++) {
      if (j == x) {
        k--;
        continue;
      }
      res[i - 1][k] = a[i][j];
    }
  return res;
}
