#include <stdio.h>

int input(int *a, int *n);
void sort(int *a, int n);
void output(int *a, int n);

int main() {
  int NMAX = 10;
  int data[NMAX], result;
  result = input(data, &NMAX);
  if (result == 1) {
    sort(data, NMAX);
    output(data, NMAX);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *a, int *n) {
  int result = 1;
  int temp;

  for (int *p = a; (p - a) < *n; p++) {
    if (result != 0) {
      if (scanf("%d", &temp) == 1) {
        *p = temp;
      } else {
        result = 0;
      }
    }
  }
  return result;
}

void sort(int *a, int n) {
  int temp;
  for (int i = 0; i < n; i++) {
    for (int *p = a; p < &a[n] - 1; p++) {
      if (*p > *(p + 1)) {
        temp = *p;
        *p = *(p + 1);
        *(p + 1) = temp;
      }
    }
  }
}

void output(int *a, int n) {
  for (int *p = a; p < &a[n]; p++)
    (p == &a[n - 1]) ? (printf("%d", *p)) : (printf("%d ", *p));
}
