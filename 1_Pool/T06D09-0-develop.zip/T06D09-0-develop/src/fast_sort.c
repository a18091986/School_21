#include <stdio.h>

int input(int *a, int *n);
void sort(int *a, int n);
void output(int *a, int n);
void quick_sort(int *a, int fst, int lst);
void piramid(int *a, int n);
void stack(int *a, int top, int bot);

int main() {
  int NMAX = 10;
  int data[NMAX], result;
  result = input(data, &NMAX);
  if (result == 1) {
    piramid(data, NMAX);
    output(data, NMAX);
    printf("\n");
    quick_sort(data, 0, NMAX - 1);
    output(data, NMAX);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *a, int *n) {
  int result = 1;
  int temp;

  for (int *p = a; (p - a) < *n; p++) {
    if (result != 0) {
      if (scanf("%d", &temp) == 1) {
        *p = temp;
      } else {
        result = 0;
      }
    }
  }
  return result;
}

void swap(int *p1, int *p2) {
  int temp;
  temp = *p1;
  *p1 = *p2;
  *p2 = temp;
}

void quick_sort(int *a, int fst, int lst) {
  if (fst < lst) {
    int lft = fst, rght = lst, middle = a[(lft + rght) / 2];
    do {
      while (a[lft] < middle)
        lft++;
      while (a[rght] > middle)
        rght--;
      if (lft <= rght) {
        swap(a + lft, a + rght);
        lft++;
        rght--;
      }
    } while (lft <= rght);
    quick_sort(a, fst, rght);
    quick_sort(a, lft, lst);
  }
}

void stack(int *a, int top, int bot) {
  int m_ch, ready = 0;
  while ((top * 2 <= bot) && (!ready)) {
    if (top * 2 == bot)
      m_ch = top * 2;
    else if (a[top * 2] > a[top * 2 + 1])
      m_ch = top * 2;
    else
      m_ch = top * 2 + 1;
    if (a[top] < a[m_ch]) {
      int temp = a[top];
      a[top] = a[m_ch];
      a[m_ch] = temp;
      top = m_ch;
    } else {
      ready = 1;
    }
  }
}

void piramid(int *a, int n) {
  for (int i = n / 2; i >= 0; i--)
    stack(a, i, n - 1);
  for (int i = n - 1; i >= 1; i--) {
    int temp = a[0];
    a[0] = a[i];
    a[i] = temp;
    stack(a, 0, i - 1);
  }
}

void output(int *a, int n) {
  for (int *p = a; p < &a[n]; p++)
    (p == &a[n - 1]) ? (printf("%d", *p)) : (printf("%d ", *p));
}
