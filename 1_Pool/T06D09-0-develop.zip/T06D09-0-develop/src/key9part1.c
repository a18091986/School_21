/*------------------------------------
        Здравствуй, человек!
        Чтобы получить ключ
        поработай с комментариями.
-------------------------------------*/

#include <stdio.h>
#define NMAX 10
int input(int *numbers, int *length);
void output(int *buffer, int out_arr_count);
int sum_numbers(int *numbers, int length);
int find_numbers(int *buffer, int length, int number, int *numbers);
/*------------------------------------
        Функция получает массив данных
        через stdin.
        Выдает в stdout особую сумму
        и сформированный массив
        специальных элементов
        (выбранных с помощью найденной суммы):
        это и будет частью ключа
-------------------------------------*/
int main() {
  int n, numbers[NMAX], buffer[NMAX], result, sum, out_arr_count;
  result = input(numbers, &n);
  if (result == 1) {
    sum = sum_numbers(numbers, n);
    out_arr_count = find_numbers(buffer, n, sum, numbers);
    output(buffer, out_arr_count);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *a, int *n) {
  int result = 1;
  if ((scanf("%d", n) != 1) || (*n <= 0)) {
    result = 0;
  } else {
    int temp;
    for (int *p = a; (p - a) < *n; p++) {
      if (scanf("%d", &temp) == 1) {
        *p = temp;
      } else {
        result = 0;
      }
    }
  }
  return result;
}

/*------------------------------------
        Функция должна находить
        сумму четных элементов
        с 0-й позиции.
-------------------------------------*/
int sum_numbers(int *buffer, int length) {
  int sum = 0;

  for (int i = 0; i < length; i++) {
    (buffer[i] % 2 == 0) ? (sum = sum + buffer[i]) : (sum += 0);
  }
  printf("%d\n", sum);
  return sum;
}

/*------------------------------------
        Функция должна находить
        все элементы, на которые нацело
        делится переданное число и
        записывает их в выходной массив.
-------------------------------------*/
int find_numbers(int *buffer, int length, int number, int *numbers) {
  int out_arr_count = 0;
  for (int *p = numbers; p - numbers < length; p++) {
    if (*p != 0) {
      if (number % *p == 0) {
        buffer[out_arr_count] = *p;
        out_arr_count++;
      }
    }
  }
  return out_arr_count;
}

void output(int *buffer, int out_arr_count) {
  for (int *p = buffer; p - buffer < out_arr_count; p++) {
    if (p - buffer < out_arr_count - 1)
      printf("%d ", *p);
    else
      printf("%d", *p);
  }
}
