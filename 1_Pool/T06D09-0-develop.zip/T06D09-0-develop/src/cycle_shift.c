#include <stdio.h>
#define NMAX 10
int input(int *numbers, int *length, int *move);
void output(int *a, int n);
void moving(int *a, int move, int n);
void swap(int *p1, int *p2);

int main() {
  int n, numbers[NMAX], result, move;
  result = input(numbers, &n, &move);
  if (result == 1) {
    moving(numbers, move, n);
    output(numbers, n);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *a, int *n, int *move) {
  int result = 1;
  if ((scanf("%d", n) != 1) || (*n <= 0)) {
    result = 0;
  } else {
    int temp;
    for (int *p = a; (p - a) < *n; p++) {
      if (scanf("%d ", &temp) == 1) {
        *p = temp;
      } else {
        result = 0;
      }
    }
    if (scanf("%d", move) != 1) {
      result = 0;
    }
  }
  return result;
}

void swap(int *p1, int *p2) {
  int temp;
  temp = *p1;
  *p1 = *p2;
  *p2 = temp;
}

void moving(int *a, int move, int n) {
  if (move > 0) {
    for (int j = 0; j < move; j++) {
      for (int i = 0; i < n - 1; i++) {
        swap(&a[i], &a[i + 1]);
      }
    }
  } else {
    for (int j = 0; j < (-1) * move; j++) {
      for (int i = n - 1; i > 0; i--) {
        swap(&a[i], &a[i - 1]);
      }
    }
  }
}

void output(int *a, int n) {
  for (int *p = a; p - a < n; p++) {
    if (p - a < n - 1)
      printf("%d ", *p);
    else
      printf("%d", *p);
  }
}
