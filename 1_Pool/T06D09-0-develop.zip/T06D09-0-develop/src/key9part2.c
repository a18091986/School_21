#include <stdio.h>

#define LEN 100

void sum(int *buff1, int *buff2, int *result, int result_length);
void sub(int *buff1, int *buff2, int *result, int result_length);
int input(int *arr, int *n);
void output(int *arr, int n);
void massiv_prepare(int *arr, int *len, int max_len);
void inverse(int *a, int n);
void swap(int *p1, int *p2);
void massiv_reduce(int *arr, int *len);

/*
    Беззнаковая целочисленная длинная арифметика
    с использованием массивов.
    Ввод:
     * 2 длинных числа в виде массивов до 100 элементов
     * В один элемент массива нельзя вводить число > 9
    Вывод:
     * Результат сложения и разности чисел-массивов
    Пример:
     * 1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 6 1
       2 9

       1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 9 0
       1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 3 2
*/
int main() {
  int result_input_arr_1 = 1, result_input_arr_2 = 1, len_f = LEN, len_s = LEN,
      len_r, f_array[LEN], s_array[LEN], s_result[LEN + 1];
  result_input_arr_1 = input(f_array, &len_f);
  result_input_arr_2 = input(s_array, &len_s);
  int max_len = (len_f > len_s) ? (len_f) : (len_s);
  if ((result_input_arr_1 + result_input_arr_2) == 0) {
    inverse(f_array, len_f);
    inverse(s_array, len_s);
    massiv_prepare(f_array, &len_f, max_len);
    massiv_prepare(s_array, &len_s, max_len);
    len_r = (len_f > len_s) ? (len_f + 1) : (len_s + 1);
    sum(f_array, s_array, s_result, len_r);
    sub(f_array, s_array, s_result, len_r);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *arr, int *n) {
  int ok_flag = 0;
  int count = 0;
  char c = ' ';
  while ((count <= *n) && (ok_flag == 0) && (c != '\n')) {
    if ((scanf("%d%c", &arr[count], &c)) == 2) {
      count += 1;
    } else {
      ok_flag = 1;
      break;
    }
  }
  *n = count;
  return ok_flag;
}

void massiv_prepare(int *arr, int *len, int max_len) {
  for (int i = *len; i < max_len; i++) {
    *len += 1;
    arr[i] = 0;
  }
}

void massiv_reduce(int *arr, int *len) {
  int i = 0;
  while (arr[*len - 1 - i] == 0) {
    *len = *len - 1;
    i++;
  }
}

void swap(int *p1, int *p2) {
  int temp;
  temp = *p1;
  *p1 = *p2;
  *p2 = temp;
}

void inverse(int *a, int n) {
  for (int j = 0; j < n / 2; j++) {
    swap(&a[j], &a[n - 1 - j]);
  }
}

void sum(int *arr_f, int *arr_s, int *result, int result_length) {
  int sum = 0;
  for (int i = 0; i < result_length - 1; i++) {
    result[i] = arr_f[i] + arr_s[i];
  }
  for (int i = 0; i < result_length; i++) {
    if (result[i] >= 10) {
      result[i] = result[i] % 10;
      result[i + 1]++;
    }
  }
  massiv_reduce(result, &result_length);
  inverse(result, result_length);
  for (int i = 0; i < result_length - 1; i++) {
    (result[i] > 0) ? (sum++) : (sum);
  }
  if (sum == 0) {
    printf("0");
  } else {
    output(result, result_length);
  }
}

void sub(int *arr_f, int *arr_s, int *result, int result_length) {
  int sum = 0;
  massiv_prepare(result, &result_length, result_length);
  for (int i = 0; i < result_length; i++) {
    result[i] = 0;
  }
  for (int i = 0; i < result_length - 1; i++) {
    if (arr_f[i] - arr_s[i] < 0) {
      result[i] = 0;
      result[i + 1] -= 1;
    } else {
      result[i] = arr_f[i] - arr_s[i];
    }
  }
  for (int i = 0; i < result_length - 1; i++) {
    (result[i] > 0) ? (sum++) : (sum);
  }
  if (result[result_length - 1] < 0) {
    printf("n/a");
  } else if (sum == 0) {
    printf("0");
  } else {
    inverse(result, result_length - 1);
    output(result, result_length - 1);
  }
}

void output(int *arr, int n) {
  int first_digit = 0;
  for (int *p = arr; p - arr < n; p++) {
    if (p - arr == n - 1) {
      printf("%d\n", *p);
    } else {
      if (*p != 0) {
        printf("%d ", *p);
        first_digit = 1;
      } else if ((*p == 0) && (first_digit == 0)) {
      }
    }
  }
}
