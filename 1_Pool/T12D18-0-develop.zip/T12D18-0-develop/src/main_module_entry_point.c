#include <stdio.h>
#include <time.h>
#include "print_module.h"
#include "documentation_module.h"
int main() {
#if F == 1
    print_log(print_char, Module_load_success_message);
#elif F == 2
//    //availability_mask = check_available_documentation_module(validate, Documents_count, Documents);
//    int * availability_mask[16];
//
//    availability_mask = check_available_documentation_module(validate, Documents_count, Documents);
//
//    for(int i = 0; i < 3; i++)
//        printf("%d", availability_mask[i]);
//
//    //  Output availability for each document....
#endif
    return 0;
}
