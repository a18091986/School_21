#include "documentation_module.h"

int validate(char* data) {
//    char * Available_document = "Available_document";
    int validation_result = !strcmp(data, Available_document);
    return validation_result;
}

int* check_available_documentation_module(int (*validate)(char*), int document_count, ...) {
    int out[16];
    int i = 0;
    for (int *ptr = &document_count; document_count > 0; document_count--) {
        out[i] = validate((char *)*(++ptr));
        i++;
    }
}
