#include <stdio.h>
#include <time.h>
#include "print_module.h"

char print_char(char ch) {
    return putchar(ch);
}

void print_log(char (*print)(char), char* message) {
    printf("%s ", Log_prefix);
    time_t current_time;
    struct tm * time_info;
    char timeString[9];
    time(&current_time);
    time_info = localtime(&current_time);
    strftime(timeString, sizeof(timeString), "%H:%M:%S", time_info);
    printf("%s ", timeString);
    for (int i = 0; message[i] != '\0'; i++) {
        print(message[i]);
    }
}
