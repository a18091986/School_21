#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>



void draw(int row, int col, int matr[row][col]);
void matr_initialise(int row, int col, int matr[row][col]);
void now_analyse(int row, int col, int now[row][col], int next[row][col]);
void save_next_to_now(int row, int col, int now[row][col], int next[row][col]);
int check_status(int ROWS, int COLS, int array[ROWS][COLS], int i, int j);
int key_handler(int *time_of_epoch, int *count_of_epoch);
void time_and_count_of_epoch(int *time_of_epoch, int *count_of_epoch);

int main() {
  int row = 25, col = 80, now[row][col], next[row][col];
  int time_of_epoch = 1e6;
  int count_of_epoch = 10;
  int key = 0;
  matr_initialise(row, col, now);
  draw(row, col, now);
  while (key != 1) {
    for (int i = 0; i < count_of_epoch; ++i) {
      now_analyse(row, col, now, next);
      draw(row, col, next);
      save_next_to_now(row, col, now, next);
      usleep(time_of_epoch);
      if (i == count_of_epoch - 1) {
        key = key_handler(&time_of_epoch, &count_of_epoch);
        if (key == 2) {
          time_and_count_of_epoch(&time_of_epoch, &count_of_epoch);
        } else if (key == 3) {
          i = 0;
        }
      }
    }
  }
  return 0;
}

int key_handler(int *time_of_epoch, int *count_of_epoch) {
  int result = 0;
  char key;
  printf(
      " - Для окончания игры введите 'q'.\n - Для продолжения с текущими "
      "настройками (%d эпох(и), длительность каждой %.6lf секунд(a/ы)) введите "
      "'c'.\n - Для "
      "изменения настроек введите 'e'.\n",
      *count_of_epoch, (double)*time_of_epoch / 1000000);
  while (result == 0) {
    if (scanf("\n%c", &key) == 1) {
      if ((key == 'q') || (key == 'Q')) {
        result = 1;
      } else if ((key == 'e') || (key == 'E')) {
        result = 2;
      } else if ((key == 'c') || (key == 'C')) {
        result = 3;
      } else {
        printf("Некорректный ввод. Повторите\n");
        result = 0;
      }
    }
  }
  return result;
}

void time_and_count_of_epoch(int *time_of_epoch, int *count_of_epoch) {
  while (getchar() != '\n')
    {}
  int result = 0;
  printf(
      "Введите два целых неотрицательных числа через пробел:\n - длительность "
      "одной эпохи в миллисекундах\n - количество эпох\n");
  while (result == 0) {
    if (scanf("%d%d", time_of_epoch, count_of_epoch) == 2) {
      while (getchar() != '\n')
        {}
      *time_of_epoch *= 1000;
      result = 1;
    } else {
      while (getchar() != '\n')
        {}
      printf("Некорректный ввод. Повторите\n");
    }
  }
}

void draw(int row, int col, int matr[row][col]) {
  for (int i = -1; i <= row; i++) {
    for (int j = -1; j <= col; j++) {
      if ((i == -1) || (i == row))
        printf("-");
      else if ((j == -1) || (j == col))
        printf("|");
      else
        (matr[i][j] == 1) ? (printf("*")) : (printf(" "));
    }
    printf("\n");
  }
}

void matr_initialise(int row, int col, int matr[row][col]) {
  if (!isatty(fileno(stdin))) {
    for (int i = 0; i < row; ++i)
      for (int j = 0; j < col; ++j)
        if (!(scanf("%d",  &matr[i][j]) == 1)) {
          continue;
        }
    if (!freopen("/dev/tty", "r", stdin)) {
      perror("/dev/tty");
      exit(1);
    }
  }
}

void now_analyse(int row, int col, int now[row][col], int next[row][col]) {
  for (int i = 0; i < row; ++i)
    for (int j = 0; j < col; ++j) {
      next[i][j] = check_status(row, col, now, i, j);
    }
}

void save_next_to_now(int row, int col, int now[row][col], int next[row][col]) {
  for (int i = 0; i < row; ++i)
    for (int j = 0; j < col; ++j)
      now[i][j] = next[i][j];
}

int check_status(int ROWS, int COLS, int array[ROWS][COLS], int i, int j) {
  int summ = 0;
  int stat = array[i][j];
  summ -= stat;
  for (int dy = -1; dy <= 1; dy++) {
    for (int dx = -1; dx <= 1; dx++) {
      int temp_i = i;
      int temp_j = j;
      temp_i = (temp_i + dy + ROWS) % ROWS;
      temp_j = (temp_j + dx + COLS) % COLS;
      summ += array[temp_i][temp_j];
    }
  }
  if ((stat == 1) && ((summ != 2) && (summ != 3)))
    stat = 0;

  if ((stat == 0) && (summ == 3))
    stat = 1;
  return stat;
}
