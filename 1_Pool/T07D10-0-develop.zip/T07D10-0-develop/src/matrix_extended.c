#include <stdio.h>
#include <stdlib.h>
#define NMAX 100

int matrix_size(int *n_row, int *n_col, int memory_allocation_case);
int input_case();
int static_matrix(int n_row, int n_col);
int matrix_input_pointers_arrays_buffer(int row, int col);
int matrix_input_pointers_to_arrays(int n_row, int n_col);
int matrix_input_pointers_to_segments(int n_row, int n_col);
void matrix_output(int **matrix, int n_row, int n_col);
void matrix_static_output(int *matrix, int row, int col);
void matrix_max_row_dyn(int **single_array_matrix, int row, int col);
void matrix_max_row_stat(int *matrix, int row, int col);
void matrix_min_col_dyn(int **single_array_matrix, int row, int col);
void matrix_min_col_stat(int *matrix, int row, int col);

int main() {
  int n_row, n_col, success, memory_allocation_case;
  memory_allocation_case = input_case();
  if ((memory_allocation_case == 1) || (memory_allocation_case == 2) ||
      (memory_allocation_case == 3) || (memory_allocation_case == 4)) {
    success = matrix_size(&n_row, &n_col, memory_allocation_case);
    if (success) {
      if (memory_allocation_case == 1)
        success = static_matrix(n_row, n_col);
      else if (memory_allocation_case == 2)
        success = matrix_input_pointers_arrays_buffer(n_row, n_col);
      else if (memory_allocation_case == 3)
        success = matrix_input_pointers_to_arrays(n_row, n_col);
      else if (memory_allocation_case == 4)
        success = matrix_input_pointers_to_segments(n_row, n_col);
      if (success == 0) {
        printf("n/a");
      }
    } else {
      printf("n/a");
    }
  } else {
    printf("n/a");
  }

  return 0;
}

int matrix_size(int *n_row, int *n_col, int memory_allocation_case) {
  int success = 1;
  if ((scanf("%d%d", n_row, n_col) != 2) || *n_row <= 0 || *n_col <= 0) {
    success = 0;
  } else {
    if ((memory_allocation_case == 1) && ((*n_row > 100) || (*n_col > 100))) {
      success = 0;
    } else {
      success = 1;
    }
  }
  return success;
}

int input_case() {
  int n, memory_allocation_case = 0;
  if (scanf("%d", &n) == 1)
    if ((n == 1) || (n == 2) || (n == 3) || (n == 4))
      memory_allocation_case = n;
  return memory_allocation_case;
}

int static_matrix(int row, int col) {
  int success = 1;
  int matrix[row][col];

  for (int i = 0; i < row; i++)
    for (int j = 0; j < col; j++)
      matrix[i][j] = 0;

  for (int i = 0; i < row; i++)
    for (int j = 0; j < col; j++)
      (scanf("%d", &matrix[i][j]) == 1) ? (success = 1) : (success = 0);

  if (success == 1) {
    matrix_static_output(&matrix[0][0], row, col);
    matrix_max_row_stat(&matrix[0][0], row, col);
    matrix_min_col_stat(&matrix[0][0], row, col);
  }
  return success;
}

int matrix_input_pointers_arrays_buffer(int row, int col) {
  int success = 1;

  int **single_array_matrix =
      malloc(row * col * sizeof(int) + row * sizeof(int *));
  if (single_array_matrix != NULL) {
    int *ptr = (int *)(single_array_matrix + row);

    for (int i = 0; i < row; i++)
      single_array_matrix[i] = ptr + col * i;

    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++)
        single_array_matrix[i][j] = 0;
    }

    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++)
        (scanf("%d", &single_array_matrix[i][j]) == 1) ? (success = 1)
                                                       : (success = 0);
    }

    if (success == 1) {
      matrix_output(single_array_matrix, row, col);
      matrix_max_row_dyn(single_array_matrix, row, col);
      matrix_min_col_dyn(single_array_matrix, row, col);
    }
    free(single_array_matrix);
  } else {
    success = 0;
  }
  return success;
}

int matrix_input_pointers_to_arrays(int n_row, int n_col) {
  int success = 1;

  int **pointer_array = malloc(n_row * sizeof(int *));
  if (pointer_array != NULL) {
    for (int i = 0; i < n_row; i++)
      pointer_array[i] = malloc(n_col * sizeof(int));

    for (int i = 0; i < n_row; i++) {
      for (int j = 0; j < n_col; j++)
        pointer_array[i][j] = 0;
    }

    for (int i = 0; i < n_row; i++) {
      for (int j = 0; j < n_col; j++)
        (scanf("%d", &pointer_array[i][j]) == 1) ? (success = 1)
                                                 : (success = 0);
    }

    if (success == 1) {
      matrix_output(pointer_array, n_row, n_col);
      matrix_max_row_dyn(pointer_array, n_row, n_col);
      matrix_min_col_dyn(pointer_array, n_row, n_col);
    }

    for (int i = 0; i < n_row; i++)
      free(pointer_array[i]);

    free(pointer_array);
  } else {
    success = 0;
  }
  return success;
}

int matrix_input_pointers_to_segments(int row, int col) {
  int success = 1;

  int **pointer_array = malloc(row * sizeof(int *));
  int *values_array = malloc(row * col * sizeof(int));

  if ((pointer_array != NULL) && (values_array != NULL)) {
    for (int i = 0; i < row; i++)
      pointer_array[i] = values_array + col * i;

    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++)
        pointer_array[i][j] = 0;
    }

    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++)
        (scanf("%d", &pointer_array[i][j]) == 1) ? (success = 1)
                                                 : (success = 0);
    }

    if (success == 1) {
      matrix_output(pointer_array, row, col);
      matrix_max_row_dyn(pointer_array, row, col);
      matrix_min_col_dyn(pointer_array, row, col);
    }

    free(values_array);
    free(pointer_array);
  } else {
    success = 0;
  }
  return success;
}

void matrix_output(int **single_array_matrix, int row, int col) {
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++)
      (j != col - 1) ? (printf("%d ", single_array_matrix[i][j]))
                     : (printf("%d", single_array_matrix[i][j]));
    if (i != row - 1) {
      printf("\n");
    }
  }
}

void matrix_static_output(int *matrix, int row, int col) {
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++)
      (j != col - 1) ? (printf("%d ", matrix[i * col + j]))
                     : (printf("%d", matrix[i * col + j]));
    if (i != row - 1) {
      printf("\n");
    }
  }
}

void matrix_max_row_dyn(int **single_array_matrix, int row, int col) {
  printf("\n");
  for (int i = 0; i < row; i++) {
    int tempmax = single_array_matrix[i][0];
    for (int j = 0; j < col; j++) {
      (single_array_matrix[i][j] > tempmax)
          ? (tempmax = single_array_matrix[i][j])
          : (tempmax = tempmax);
    }
    (i != row - 1) ? (printf("%d ", tempmax)) : (printf("%d", tempmax));
  }
}

void matrix_max_row_stat(int *matrix, int row, int col) {
  printf("\n");
  for (int i = 0; i < row; i++) {
    int tempmax = matrix[i * col];
    for (int j = 0; j < col; j++) {
      (matrix[i * col + j] > tempmax) ? (tempmax = matrix[i * col + j])
                                      : (tempmax = tempmax);
    }
    (i != row - 1) ? (printf("%d ", tempmax)) : (printf("%d", tempmax));
  }
}

void matrix_min_col_dyn(int **single_array_matrix, int row, int col) {
  printf("\n");
  for (int i = 0; i < col; i++) {
    int tempmin = single_array_matrix[0][i];
    for (int j = 0; j < row; j++) {
      (single_array_matrix[j][i] < tempmin)
          ? (tempmin = single_array_matrix[i][j])
          : (tempmin = tempmin);
    }
    (i != col - 1) ? (printf("%d ", tempmin)) : (printf("%d", tempmin));
  }
}

void matrix_min_col_stat(int *matrix, int row, int col) {
  printf("\n");
  for (int j = 0; j < row; j++) {
    int tempmin = matrix[j];
    for (int i = 0; i < row * col; i += row) {
      (matrix[j + i] < tempmin) ? (tempmin = matrix[j + i])
                                : (tempmin = tempmin);
    }
    (j != row - 1) ? (printf("%d ", tempmin)) : (printf("%d", tempmin));
  }
}
