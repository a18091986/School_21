#include <stdio.h>
#include <stdlib.h>

int input(int *a, int *n);
void sort(int *a, int n);
void output(int *a, int n);

int main() {
  int NMAX = 10, result, *a;
  a = (int *)malloc(NMAX * sizeof(int));
  result = input(a, &NMAX);
  if (result == 1) {
    sort(a, NMAX);
    output(a, NMAX);
  } else {
    printf("n/a");
  }
  free(a);
  return 0;
}

int input(int *a, int *n) {
  int result = 1;
  int temp;
  for (int *p = a; (p - a) < *n; p++) {
    if (result != 0) {
      if (scanf("%d", &temp) == 1) {
        *p = temp;
      } else {
        result = 0;
      }
    }
  }
  return result;
}

void sort(int *a, int n) {
  int temp;
  for (int i = 0; i < n; i++) {
    for (int *p = a; p < &a[n] - 1; p++) {
      if (*p > *(p + 1)) {
        temp = *p;
        *p = *(p + 1);
        *(p + 1) = temp;
      }
    }
  }
}

void output(int *a, int n) {
  for (int *p = a; p < &a[n]; p++)
    (p == &a[n - 1]) ? (printf("%d", *p)) : (printf("%d ", *p));
}
