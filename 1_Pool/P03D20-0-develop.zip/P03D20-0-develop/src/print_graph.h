#ifndef SRC_PRINT_GRAPH_H_
#define SRC_PRINT_GRAPH_H_

void print_func(char *data);

#endif  // SRC_PRINT_GRAPH_H_
