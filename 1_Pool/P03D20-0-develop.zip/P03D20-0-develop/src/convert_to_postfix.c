#include "stack_to_convert.h"

#define SIN 'a'
#define COS 'b'
#define TAN 'c'
#define CTG 'd'
#define SQRT 'e'
#define LN 'f'
#define MINUS '~'

int priority(char c) {
    int flag = -1;
    if (c == '(')
        flag = 0;
    else if (c == '+' || c == '-')
        flag = 1;
    else if (c == '*' || c == '/')
        flag = 2;
    else if (c == SIN || c == COS || c == TAN)
        flag = 3;
    else if (c == CTG || c == SQRT || c == LN)
        flag = 3;
    else if (c == '^')
        flag = 5;
    else if (c == MINUS)
        flag = 6;
    return flag;
}

void interpritation_to_postfix(Stack s, char *in_exp, int lenth, char *post_exp) {
    int count = 0;
    char temp;
    for (int i = 0; i < lenth; i++) {
        if ((in_exp[i] < 58 && in_exp[i] > 47) || in_exp[i] == 'x' || in_exp[i] == '.') {
            post_exp[count] = in_exp[i];
            count++;
            while ((in_exp[i + 1] < 58 && in_exp[i + 1] > 47) || in_exp[i + 1] == '.') {
                post_exp[count] = in_exp[i + 1];
                count++;
                i++;
            }
            post_exp[count] = '|';
            count++;
        } else if (in_exp[i] == '(') {
            push(&s, in_exp[i]);
        } else if (in_exp[i] == ')') {
            while ((temp = pop(&s)) != '(') {
                post_exp[count] = temp;
                count++;
                post_exp[count] = '|';
                count++;
            }
        } else {
            while (priority(top(&s)) >= priority(in_exp[i])) {
                post_exp[count] = pop(&s);
                count++;
                post_exp[count] = '|';
                count++;
            }
            push(&s, in_exp[i]);
        }
    }
    while (top(&s) != '\0') {
        post_exp[count] = '|';
        count++;
        post_exp[count] = pop(&s);
        count++;
    }
    destroy(&s);
}
