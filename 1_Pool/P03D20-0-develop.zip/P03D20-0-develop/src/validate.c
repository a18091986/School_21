#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIN 'a'
#define COS 'b'
#define TAN 'c'
#define CTG 'd'
#define SQRT 'e'
#define LN 'f'
#define MINUS '~'

#define is_ln(X) ((X)[0] == 'l' && (X)[1] == 'n' && (X)[2] == '(')
#define is_sin(X) ((X)[0] == 's' && (X)[1] == 'i' && (X)[2] == 'n' && (X)[3] == '(')
#define is_cos(X) ((X)[0] == 'c' && (X)[1] == 'o' && (X)[2] == 's' && (X)[3] == '(')
#define is_tan(X) ((X)[0] == 't' && (X)[1] == 'a' && (X)[2] == 'n' && (X)[3] == '(')
#define is_ctg(X) ((X)[0] == 'c' && (X)[1] == 't' && (X)[2] == 'g' && (X)[3] == '(')
#define is_sqrt(X) ((X)[0] == 's' && (X)[1] == 'q' && (X)[2] == 'r' && (X)[3] == 't' && (X)[4] == '(')

char *input() {
    char *str = (char *)malloc(500 * sizeof(char));
    size_t size = 500;
    size_t length = 0;
    char c = 0;
    while ((c = getchar()) != '\n' && c != 0) {
        str[length] = c;
        length++;

        if (size - length < 20) {
            size = size + 500;
            char *ptr = realloc(str, size * sizeof(char));
            if (ptr) {
                str = ptr;
            }
        }
    }
    str[length] = 0;
    return str;
}

void delete_spaces(char *str) {
    size_t i = 0, j = 0;
    while (str[i]) {
        if (str[i] != ' ') {
            str[j] = str[i];
            j++;
        }
        i++;
    }
    str[j] = 0;
}

void simplifier(char *str) {
    size_t i = 0, j = 0;
    while (str[i]) {
        if (is_ln(str + i)) {
            str[j] = LN;
            i = i + 1;
        } else if (is_sin(str + i)) {
            str[j] = SIN;
            i = i + 2;
        } else if (is_cos(str + i)) {
            str[j] = COS;
            i = i + 2;
        } else if (is_tan(str + i)) {
            str[j] = TAN;
            i = i + 2;
        } else if (is_ctg(str + i)) {
            str[j] = CTG;
            i = i + 2;
        } else if (is_sqrt(str + i)) {
            str[j] = SQRT;
            i = i + 3;
        } else {
            str[j] = str[i];
        }
        i++;
        j++;
    }
    str[j] = 0;
}

// | ====================== |
// | functions for validate |
// V ====================== V

void skip_num(char **str) {
    int point = 1;
    while ((**str <= '9' && **str >= '0') || (**str == '.' && point)) {
        if (**str == '.') point = 0;
        (*str)++;
    }
}

int operand_processor(char **str, int *operand, int *bi_operator, int *operand_abscense, int *left_bracket) {
    int result = 1;
    double temp = 0;
    if ((*str)[0] == '-' && (*str)[-1] != MINUS) {
        **str = MINUS;
        (*str)++;
    } else if (**str == 'x') {
        *operand = 0;
        *operand_abscense = 0;
        *bi_operator = 1;
        (*str)++;
    } else if (**str != '-' && **str != '+' && sscanf((*str), "%lf", &temp)) {
        *operand = 0;
        *operand_abscense = 0;
        *bi_operator = 1;
        skip_num(str);
    } else if (is_ln(*str)) {
        *str = *str + 3;
        (*left_bracket)++;
    } else if (is_sin(*str) || is_cos(*str) || is_tan(*str) || is_ctg(*str)) {
        *str = *str + 4;
        (*left_bracket)++;
    } else if (is_sqrt(*str)) {
        *str = *str + 5;
        (*left_bracket)++;
    } else if (**str == '(') {
        (*str)++;
        (*left_bracket)++;
    } else {
        result = 0;
    }
    return result;
}

int bi_operator_processor(char **str, int *operand, int *bi_operator, int *right_bracket) {
    int result = 1;
    if (**str == '+' || **str == '-' || **str == '*' || **str == '/' || **str == '^') {
        *bi_operator = 0;
        *operand = 1;
        (*str)++;
    } else if (**str == ')') {
        (*right_bracket)++;
        (*str)++;
    } else {
        result = 0;
    }
    return result;
}

// |======================|
// |functions for validate|
// |======================|

int validate(char *str) {
    int operand = 1, bi_operator = 0, result = (str != NULL);
    int left_bracket = 0, right_bracket = 0, operand_abscense = 1;

    while (str[0] && result) {
        if (operand) {
            result = operand_processor(&str, &operand, &bi_operator, &operand_abscense, &left_bracket);
        } else if (bi_operator) {
            result = bi_operator_processor(&str, &operand, &bi_operator, &right_bracket);
        } else {
            result = 0;
        }
    }

    if (left_bracket != right_bracket || operand_abscense) {
        result = 0;
    }

    return result;
}
