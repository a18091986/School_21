#include "stack_to_calculate.h"

#include <stdio.h>
#include <stdlib.h>

struct stack *init_lear(struct operand const *new_operand) {
    struct stack *new_stack = (struct stack *)malloc(sizeof(struct stack));
    if (new_stack) {
        new_stack->top = (struct node *)malloc(sizeof(struct node));
        if (new_stack->top) {
            new_stack->top->next = NULL;
            new_stack->top->val = *new_operand;
        }
    }
    return new_stack;
}

struct operand pop_lear(struct stack *stack) {
    struct operand last_operand;
    operand_init(last_operand);
    if (stack && stack->top) {
        last_operand = stack->top->val;
        struct node *tmp = stack->top->next;
        free(stack->top);
        stack->top = tmp;
    }
    return last_operand;
}

void push_lear(struct stack *stack, struct operand const *new_operand) {
    if (stack) {
        struct node *tmp = stack->top;
        stack->top = (struct node *)malloc(sizeof(struct node));
        if (stack->top) {
            stack->top->next = tmp;
            stack->top->val = *new_operand;
        } else {
            stack->top = tmp;
        }
    }
}

void destroy_lear(struct stack *stack) {
    if (stack) {
        destroy_list(stack->top);
        stack->top = NULL;
    }
    free(stack);
}

void destroy_list(struct node *root) {
    if (root) {
        destroy_list(root->next);
        free(root);
    }
}
