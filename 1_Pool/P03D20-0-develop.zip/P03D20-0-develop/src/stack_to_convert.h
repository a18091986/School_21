#ifndef SRC_STACK_TO_CONVERT_H_
#define SRC_STACK_TO_CONVERT_H_
#include <stdio.h>

typedef struct {
    char *values;
    int len;
    int c;
} Stack;

Stack init();
void push(Stack *s, char value);
char pop(Stack *s);
void destroy(Stack *s);
char top(Stack *s);

#endif  // SRC_STACK_TO_CONVERT_H_
