#ifndef SRC_CONVERT_TO_POSTFIX_H_
#define SRC_CONVERT_TO_POSTFIX_H_
#include "stack_to_convert.h"

int priority(char c);
void interpritation_to_postfix(Stack s, char *in_exp, int lenth, char *post_exp);

#endif  // SRC_CONVERT_TO_POSTFIX_H_
