#include "stack_to_convert.h"

#include <stdio.h>
#include <stdlib.h>

Stack init() {
    Stack s = {NULL, 0, 0};
    return s;
}

void push(Stack *s, char value) {
    if (s->values == NULL || s->len == s->c) {
        s->c = (s->c + 1) * 2;
        s->values = (char *)realloc(s->values, sizeof(char) * s->c);
    }
    s->values[s->len] = value;
    s->len += 1;
}

char pop(Stack *s) {
    if (s->len == 0) {
        return 0;
    }
    s->len -= 1;
    return s->values[s->len];
}

char top(Stack *s) {
    char temp = '\0';
    if (s->len != 0) temp = s->values[s->len - 1];
    return temp;
}

void destroy(Stack *s) {
    if (s->values != NULL) {
        free(s->values);
    }
    s->len = 0;
    s->c = 0;
}
