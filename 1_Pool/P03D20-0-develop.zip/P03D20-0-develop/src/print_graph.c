#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "postfix_calculation.h"

#define DELTA 2. / 24.
#define DELTA_2 1. / 24.
#define EPS 1e-3

void print_func(char *data) {
    char *temp = (char *)malloc((strlen(data) + 20) * sizeof(char));
    char flag = temp != NULL;
    for (double y = -1, result; y < 1 + 1e-6 && flag; y = y + DELTA) {
        for (double x = 0; x <= M_PI * 4; x = x + M_PI / 20.) {
            strcpy(temp, data);
            result = calculate(temp, x);
            if (result < y + DELTA_2 + EPS && result > y - DELTA_2 - EPS) {
                printf("*");
            } else {
                printf(".");
            }
        }
        printf("\n");
    }

    if (temp) free(temp);
}
