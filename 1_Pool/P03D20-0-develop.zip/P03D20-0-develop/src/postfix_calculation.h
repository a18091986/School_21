#ifndef SRC_POSTFIX_CALCULATION_H_
#define SRC_POSTFIX_CALCULATION_H_
#include "stack_to_calculate.h"

double calculate(char* string, double x);

#endif  // SRC_POSTFIX_CALCULATION_H_
