#include "postfix_calculation.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stack_to_calculate.h"

#define SIN 'a'
#define COS 'b'
#define TAN 'c'
#define CTAN 'd'
#define SQRT 'e'
#define LN 'f'
#define UMINUS '~'

struct operand case_operand_1(char const *value_part, struct operand temp_operand, double x,
                              struct stack *stack_);

struct operand case_operand_2(char const *value_part, struct operand temp_operand, struct stack *stack_);

double calculate(char *string, double x) {
    double result;
    struct stack *stack_;
    struct operand operand_;
    stack_ = init_lear(&operand_);
    char *value_part = strtok(string, "|");
    while (value_part != NULL) {
        struct operand temp_operand;
        temp_operand.num = 0;
        if (((value_part[0] >= '0') && (value_part[0] <= '9')) || (value_part[0] == 'x') ||
            (value_part[0] == '^') || (value_part[0] == '+') || (value_part[0] == '-') ||
            (value_part[0] == '*') || (value_part[0] == '/')) {
            temp_operand = case_operand_1(value_part, temp_operand, x, stack_);
        } else {
            temp_operand = case_operand_2(value_part, temp_operand, stack_);
        }
        push_lear(stack_, &temp_operand);
        value_part = strtok(NULL, "|");
    }
    result = pop_lear(stack_).num;
    destroy_lear(stack_);
    return result;
}

struct operand case_operand_1(char const *value_part, struct operand temp_operand, double x,
                              struct stack *stack_) {
    struct operand a, b;
    if ((value_part[0] >= '0') && (value_part[0] <= '9')) {
        temp_operand.num = atof(value_part);
    } else if (value_part[0] == 'x') {
        temp_operand.num = x;
    } else if ((value_part[0] == '^')) {
        a.num = pop_lear(stack_).num;
        b.num = pop_lear(stack_).num;
        temp_operand.num = pow(b.num, a.num);
    } else if (value_part[0] == '+') {
        a.num = pop_lear(stack_).num;
        b.num = pop_lear(stack_).num;
        temp_operand.num = a.num + b.num;
    } else if (value_part[0] == '-') {
        a.num = pop_lear(stack_).num;
        b.num = pop_lear(stack_).num;
        temp_operand.num = b.num - a.num;
    } else if (value_part[0] == '*') {
        a.num = pop_lear(stack_).num;
        b.num = pop_lear(stack_).num;
        temp_operand.num = a.num * b.num;
    } else if (value_part[0] == '/') {
        a.num = pop_lear(stack_).num;
        b.num = pop_lear(stack_).num;
        temp_operand.num = b.num / a.num;
    }
    return temp_operand;
}

struct operand case_operand_2(char const *value_part, struct operand temp_operand, struct stack *stack_) {
    struct operand a;
    if (value_part[0] == SIN) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)sin(a.num);
    } else if (value_part[0] == COS) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)cos(a.num);
    } else if (value_part[0] == TAN) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)tan(a.num);
    } else if (value_part[0] == CTAN) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)atan(a.num);
    } else if (value_part[0] == SQRT) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)sqrt(a.num);
    } else if (value_part[0] == LN) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)log(a.num);
    } else if (value_part[0] == UMINUS) {
        a.num = pop_lear(stack_).num;
        temp_operand.num = (double)(a.num * (-1));
    }
    return temp_operand;
}
