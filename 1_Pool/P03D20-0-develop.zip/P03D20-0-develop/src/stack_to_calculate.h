#ifndef SRC_STACK_TO_CALCULATE_H_
#define SRC_STACK_TO_CALCULATE_H_

struct operand {
    double num;
};

#define operand_init(x) x.num = 0;

struct node {
    struct operand val;
    struct node *next;
};

struct stack {
    struct node *top;
};

struct stack *init_lear(struct operand const *);
struct operand pop_lear(struct stack *stack);
void push_lear(struct stack *stack, struct operand const *new_operand);
void destroy_lear(struct stack *stack);
void destroy_list(struct node *root);

#endif  // SRC_STACK_TO_CALCULATE_H_
