#include <stdlib.h>
#include <string.h>

#include "convert_to_postfix.h"
#include "postfix_calculation.h"
#include "print_graph.h"
#include "stack_to_convert.h"
#include "validate.h"

int main() {
    Stack s = init();
    char *str = input();
    delete_spaces(str);
    if (validate(str)) {
        simplifier(str);
        char *post_exp = (char *)malloc((strlen(str) * 3 / 2 + 50) * sizeof(char));
        interpritation_to_postfix(s, str, strlen(str), post_exp);
        print_func(post_exp);
        free(post_exp);
    }
    free(str);
    destroy(&s);
    return 0;
}
