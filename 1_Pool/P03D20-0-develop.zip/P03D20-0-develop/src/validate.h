#ifndef SRC_VALIDATE_H_
#define SRC_VALIDATE_H_

char *input();
void delete_spaces(char *str);
void skip_num(char **str);
int validate(char *str);
void simplifier(char *str);

#endif  // SRC_VALIDATE_H_
