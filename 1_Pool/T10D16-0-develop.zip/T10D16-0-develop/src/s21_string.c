#include "s21_string.h"
#include <stdio.h>

size_t s21_strlen(char *str) {
  size_t length = 0;
  for (; *(str + length); length++)
  {}
  return length;
}

int s21_strcmp(char *str1, char *str2) {
  int result = 1;
  int flag = 1;
  char *p = str1;
  char *q = str2;
  while (*p && flag) {
    if (*p != *q) {
      flag = 0;
      result = *(unsigned char *)p - *(unsigned char *)q;
    }
    p++;
    q++;
  }
  if (flag == 1) {
    result = 0;
  }
  return result;
}

void s21_strcpy(char *dst, char *src) {
  int i = 0;
  while (*(src + i) != '\0') {
    *(dst + i) = *(src + i);
    i++;
  }
}

void s21_strcat(char *dst, char *append) {
  int i = 0;
  int j = 0;
  while (*(dst + i) != '\0') {
    i++;
  }
  while (*(append + j) != '\0') {
    *(dst + i) = *(append + j);
    i++;
    j++;
  }
}

char *s21_strchr(char *str, int ch) {
  int i = 0;
  while (*(str + i) != (char)ch)
    i++;
  return (str + i);
}

char *s21_strstr(char *str, char *find) {
  int flag = 0;
  char *result = NULL;
  if (s21_strlen(find) == 0) {
    result = str;
  } else {
    while (*str != '\0') {
      if ((*str == *find) && s21_strcmp(str, find) && !flag) {
        result = str;
        flag = 1;
      }
      str++;
    }
  }
  return result;
}

char *s21_strtok(char *str, char *sep) {
  char *result = NULL;
  if (s21_strstr(str, sep)) {
    result = s21_strstr(str, sep);
  }

  return result;
}
