#include "str_o.h"
#include <stdio.h>

void output(char *str) {
  size_t length = 0;
  for (; *(str + length); length++)
    printf("%c", *(str + length));
  printf("\n");
}
