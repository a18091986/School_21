#include <stdio.h>
#ifndef SRC_S21_STRING_H_
#define SRC_S21_STRING_H_
size_t s21_strlen(char *str);
int s21_strcmp(char *str1, char *str2);
void s21_strcpy(char *dst, char *src);
void s21_strcat(char *dst, char *append);
char *s21_strchr(char *str, int ch);
char *s21_strstr(char *str, char *find);
char *s21_strtok(char *str, char *sep);
#endif  // SRC_S21_STRING_H_
