#ifndef SRC_STR_O_H_
#define SRC_STR_O_H_

void output(char *str);

#endif  // SRC_STR_O_H_
