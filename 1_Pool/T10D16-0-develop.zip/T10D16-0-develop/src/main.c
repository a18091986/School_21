#include "s21_string_test.h"
#include <stdio.h>
int main(void) {
#if FUNC == 1
  s21_strlen_test();
#elif FUNC == 2
  s21_strcmp_test();
#elif FUNC == 3
  s21_strcpy_test();
#elif FUNC == 4
  s21_strcat_test();
#elif FUNC == 5
  s21_strchr_test();
#elif FUNC == 6
  s21_strstr_test();
#elif FUNC == 7
  s21_strtok_test();
#endif
  return 0;
}
