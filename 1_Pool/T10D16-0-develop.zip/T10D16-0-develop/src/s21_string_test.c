#include "s21_string_test.h"
#include "s21_string.h"
#include "str_o.h"
#include <stdio.h>

void s21_strlen_test() {
  char *str_norm = "String";
  char *str_gran = "";
  char *str_anorm = "St\0ring";
  printf("%s\n", str_norm);
  printf("%ld\n", s21_strlen(str_norm));
  (s21_strlen(str_norm) == 6) ? (printf("SUCCESS\n")) : (printf("FALSE\n"));
  printf("%s\n", str_gran);
  printf("%ld\n", s21_strlen(str_gran));
  (s21_strlen(str_gran) == 0) ? (printf("SUCCESS\n")) : (printf("FALSE\n"));
  printf("St\\0ring\n");
  printf("%ld\n", s21_strlen(str_anorm));
  (s21_strlen(str_anorm) == 2) ? (printf("SUCCESS")) : (printf("FALSE"));
}

void s21_strcmp_test() {
  char *str_norm_1 = "String";
  char *str_norm_2 = "Stri";
  printf("%s %s\n", str_norm_1, str_norm_2);
  printf("%d\n", s21_strcmp(str_norm_1, str_norm_2));
  (s21_strcmp(str_norm_1, str_norm_2) == 110) ? (printf("SUCCESS\n"))
                                              : (printf("FALSE\n"));
  char *str_gran_1 = "";
  char *str_gran_2 = "";
  printf("%s %s\n", str_gran_1, str_gran_2);
  printf("%d\n", s21_strcmp(str_gran_1, str_gran_2));
  (s21_strcmp(str_gran_1, str_gran_2) == 0) ? (printf("SUCCESS\n"))
                                            : (printf("FALSE\n"));
  char *str_anorm_1 = "\0";
  char *str_anorm_2 = "\0";
  printf("\\0 \\0\n");
  printf("%d\n", s21_strcmp(str_anorm_1, str_anorm_2));
  (s21_strcmp(str_anorm_1, str_anorm_2) == 0) ? (printf("SUCCESS"))
                                              : (printf("FALSE"));
}

void s21_strcpy_test() {
  char *src_normal = "String";
  char *src_gran = "";
  char *src_anormal = "first\0second";
  char dst_1[30];
  char dst_2[30];
  char dst_3[30];
  printf("%s\n", src_normal);
  s21_strcpy(dst_1, src_normal);
  printf("%s\n", dst_1);
  (s21_strcmp(dst_1, src_normal) == 0) ? (printf("SUCCESS\n"))
                                       : (printf("FALSE\n"));
  printf("%s\n", src_gran);
  s21_strcpy(dst_2, src_gran);
  printf("%s\n", dst_2);
  (s21_strcmp(dst_2, src_gran) == 0) ? (printf("SUCCESS\n"))
                                     : (printf("FALSE\n"));
  printf("first\\0second\n");
  s21_strcpy(dst_3, src_anormal);
  printf("%s\n", dst_3);
  (s21_strcmp(dst_3, src_anormal) == 0) ? (printf("SUCCESS"))
                                        : (printf("FALSE"));
}

void s21_strcat_test() {
  char *app_n = "first string";
  char *app_gr = "";
  char *app_an = "\0";
  char dstn_1[100] = "second string";
  char dstn_2[100] = "second string";
  char dstn_3[100] = "second string";
  char *result_1 = "second stringfirst string";

  printf("%s %s\n", dstn_1, app_n);
  s21_strcat(dstn_1, app_n);
  printf("%s\n", dstn_1);
  (s21_strcmp(dstn_1, result_1) == 0) ? (printf("SUCCESS\n"))
                                      : (printf("FALSE\n"));

  printf("%s %s\n", dstn_2, app_gr);
  s21_strcat(dstn_2, app_gr);
  printf("%s\n", dstn_2);
  (s21_strcmp(dstn_2, dstn_2) == 0) ? (printf("SUCCESS\n"))
                                    : (printf("FALSE\n"));

  printf("%s %s\n", dstn_3, app_an);
  s21_strcat(dstn_3, app_an);
  printf("%s\n", dstn_3);
  (s21_strcmp(dstn_3, dstn_3) == 0) ? (printf("SUCCESS")) : (printf("FALSE"));
}

void s21_strchr_test() {
  char *str = "StringS";
  int ch_1 = 'S';
  int ch_2 = '\0';
  int ch_3 = 'G';
  printf("%s %c\n", str, ch_1);
  printf("%ld\n", s21_strchr(str, ch_1) - str);
  ((s21_strchr(str, ch_1) - str) == 0) ? (printf("SUCCESS\n"))
                                       : (printf("FALSE\n"));
  printf("%s \\0\n", str);
  printf("%ld\n", s21_strchr(str, ch_2) - str);
  ((s21_strchr(str, ch_2) - str) == 7) ? (printf("SUCCESS\n"))
                                       : (printf("FALSE\n"));
  printf("%s %c\n", str, ch_3);
  printf("%ld\n", s21_strchr(str, ch_3) - str);
  (((s21_strchr(str, ch_3) - str) > 7) || ((s21_strchr(str, ch_3) - str) < 0))
      ? (printf("SUCCESS"))
      : (printf("FALSE"));
}

void s21_strstr_test() {
  char *str_where = "first_string";
  char *find_1 = "st";
  char *find_2 = "\0";
  char *find_3 = "FD";

  printf("%s %s\n", str_where, find_1);
  printf("%ld\n", s21_strstr(str_where, find_1) - str_where);
  ((s21_strstr(str_where, find_1) - str_where) == 3) ? (printf("SUCCESS\n"))
                                                     : (printf("FALSE\n"));

  printf("%s %s\n", str_where, find_2);
  printf("%ld\n", s21_strstr(str_where, find_2) - str_where);
  ((s21_strstr(str_where, find_2) - str_where) == 0) ? (printf("SUCCESS\n"))
                                                     : (printf("FALSE\n"));

  printf("%s %s\n", str_where, find_3);
  printf("%ld\n", s21_strstr(str_where, find_3) - str_where);
  (((s21_strstr(str_where, find_3) - str_where) > 7) ||
     ((s21_strstr(str_where, find_3) - str_where) < 0))
      ? (printf("SUCCESS"))
      : (printf("FALSE"));
}

void s21_strtok_test() {
  char *str_1 = "One Two Three";
  char *sep_1 = " ";
  char *sep_2 = "T";
  char *sep_3 = "O";
  printf("%s %s\n", str_1, sep_1);
  printf("%s\n", s21_strtok(str_1, sep_1) + 1);
  char *result_1 = "Two Three";
  (s21_strcmp((s21_strtok(str_1, sep_1) + 1), result_1) == 0)
      ? (printf("SUCCESS\n"))
      : (printf("FALSE\n"));

  printf("%s %s\n", str_1, sep_2);
  printf("%s\n", s21_strtok(str_1, sep_2) + 1);
  char *result_2 = "wo Three";
  (s21_strcmp((s21_strtok(str_1, sep_2) + 1), result_2) == 0)
      ? (printf("SUCCESS\n"))
      : (printf("FALSE\n"));

  printf("%s %s\n", str_1, sep_3);
  printf("%s\n", s21_strtok(str_1, sep_3) + 1);
  char *result_3 = "ne Two Three";
  (s21_strcmp((s21_strtok(str_1, sep_3) + 1), result_3) == 0)
      ? (printf("SUCCESS\n"))
      : (printf("FALSE\n"));
}
