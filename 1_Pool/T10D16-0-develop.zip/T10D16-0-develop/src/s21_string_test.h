#ifndef SRC_S21_STRING_TEST_H_
#define SRC_S21_STRING_TEST_H_

void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();
void s21_strstr_test();
void s21_strtok_test();

#endif  // SRC_S21_STRING_TEST_H_
