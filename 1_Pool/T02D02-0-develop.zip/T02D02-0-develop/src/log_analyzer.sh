#!/bin/bash

if [ $# -lt 1 ]; then
echo "No all arguments supplied"
exit 1
fi

suffix=".log"
path=$1

if [[ ! -f "$1" ]]; then
echo "File not exists"
exit 1
fi

if [[ ! $1 == *$suffix ]]; then
echo "It's not log file"
exit 1
fi


echo $(wc $path | awk '{print $1}') $(awk '{print $1}' $path | sort | uniq | wc -l) $(awk '{print $8}' $path | sort | uniq | wc -l)
