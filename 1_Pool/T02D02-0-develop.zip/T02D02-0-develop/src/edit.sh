#!/bin/bash

if [ $# -lt 3 ]; then
echo "No all arguments supplied"
exit 1
fi 

suffix=".txt"
path=$1
search=$2
replace=$3

if [[ ! -f "$1" ]]; then
echo "File not exists"
exit 1
fi

if [[ ! $1 == *$suffix ]]; then 
echo "It's not txt file"
exit 1
fi

sha_start=$(shasum -a 256 $path | awk '{ print $1 }')

if [[ $search != "" && $search != $replace ]]; then
sed -i '' "s/"$search"/"$replace"/g" $1
fi

sha_end=$(shasum -a 256 $path | awk '{ print $1 }')

if [[ "$sha_start" != "$sha_end" ]]; then
size=$(stat -f%z $path)
date_time=$(date -r $path +%F\ %H:%M)
echo "$path - $size - $date_time - $sha_end - sha256" >> files.log
fi




