#include "list_test.h"
#include "door_struct.h"
#include "list.h"
#include <stdio.h>

int main() {
  printf("%s\n", add_door_test());
  printf("%s", remove_door_test());
  return 0;
}

char *add_door_test() {
  char *result = "FAIL";
  // создаем структуру дверей
  struct door doors[5];
  for (int i = 0; i < 5; i++) {
    doors[i].id = i;
    doors[i].status = 0;
  }

  // создаем элементы списка

  struct node *root = init(&doors[0]);

  if (root) {  // проверка на то, что вернул malloc
    struct node *second_element = add_door(root, &doors[2]);
    struct node *new_element = add_door(root, &doors[4]);
    if (new_element && second_element) {  // проверка на то, что вернул malloc
      if ((root->next == new_element) &&
          (new_element->next == second_element)) {
        result = "SUCCESS";
      }
    }
    // освобождаем все
    destroy(root);
  }
  return result;
}

char *remove_door_test() {
  char *result = "FAIL";
  // создаем структуру дверей
  struct door doors[5];
  for (int i = 0; i < 5; i++) {
    doors[i].id = i;
    doors[i].status = 0;
  }

  // создаем элементы списка
  struct node *root = init(&doors[0]);

  if (root) {  // проверка на то, что вернул malloc
    struct node *second_element = add_door(root, &doors[2]);
    struct node *to_remove = add_door(root, &doors[4]);
    remove_door(to_remove, root);
    find_door(2, root);
    struct node *new_element = add_door(root, &doors[4]);
    if (new_element && second_element) {  // проверка на то, что вернул malloc
      if ((remove_door(new_element, root) == root) &&
          (root->next == second_element)) {
        result = "SUCCESS";
      }
      // освобождаем все
    }
    destroy(root);
  }
  return result;
}
