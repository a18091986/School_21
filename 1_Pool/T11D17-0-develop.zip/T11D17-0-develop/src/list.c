#include "list.h"
#include "door_struct.h"
#include <stdio.h>
#include <stdlib.h>

struct node *init(struct door *door) {
  struct node *root;
  root = (struct node *)malloc(sizeof(struct node));
  root->door = door;
  root->next = NULL;
  return (root);
}

struct node *add_door(struct node *elem, struct door *door) {
  struct node *temp, *p;
  temp = (struct node *)malloc(sizeof(struct node));
  p = elem->next;
  elem->next = temp;
  temp->door = door;
  temp->next = p;
  return temp;
}

struct node *find_door(int door_id, struct node *root) {
  struct node *p;
  p = root;
  while (p && (p->door->id != door_id)) {
    p = p->next;
  }
  return p;
}

struct node *remove_door(struct node *elem, struct node *root) {
  struct node *temp;
  if (elem == root) {
    free(root);
    temp = NULL;
  } else {
    temp = root;
    while (temp->next != elem)
      temp = temp->next;
    temp->next = elem->next;
    free(elem);
  }
  return temp;
}

// struct node *remove_door(struct node *elem, struct node *root) {
//   struct node *temp;
//   temp = root;
//   while (temp->next != elem)
//     temp = temp->next;
//   temp->next = elem->next;
//   free(elem);
//   return temp;
// }

// void output(struct node *root) {
//   struct node *p;
//   p = root;
//   do {
//     printf("POINTER_TO_NEXT: %p, DOOR_ID: %d, DOOR_STATUS: %d\n", p->next,
//            p->door->id, p->door->status);
//     p = p->next;
//   } while (p != NULL);
//   printf("\n");
// }

void destroy(struct node *root) {
  struct node *p, *temp;
  p = root;
  do {
    temp = p->next;
    free(p);
    p = temp;
  } while (p != NULL);
}
