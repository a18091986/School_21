#include "func.h"
#ifdef LOG
#include "logger.h"
#endif
#include <stdio.h>
#include <stdlib.h>

void menu(char *path, int *path_length) {
#ifdef LOG
  FILE *file;
  char log_path[10] = "log.txt";
  file = log_init(log_path);
#endif
  int menu_case, file_was_read = 0, cezar_step = 0;
  while (menu_case != -1) {
    if (scanf("%d", &menu_case) != 1) {
      printf("n/a\n");
      getchar();
    } else if (menu_case == -1) {
#ifdef LOG
      log_close(file);
#endif
    } else if (menu_case == 1) {
      getchar();
      read_path(path, path_length);
      file_was_read = read_file(path);
#ifdef LOG
      logcat(file, "FILE READ");
#endif
    } else if (menu_case == 2) {
      getchar();
      add_to_file(path, file_was_read);
      read_file(path);
#ifdef LOG
      logcat(file, "FILE CHANGED");
#endif
    } else if (menu_case == 3) {
      getchar();
      while (!scanf("%d", &cezar_step)) {
        getchar();
        printf("n/a\n");
      }
      cezar_main(cezar_step);
    } else {
      printf("n/a\n");
    }
  }
}

void read_path(char *path, int *path_length) {
  char *temp_path;
  char c;
  int index_in_path = 0;
  while (((c = getchar()) != '\n') && c != 0) {
    path[index_in_path] = c;
    index_in_path++;
    if (index_in_path == *path_length - 1) {
      temp_path = (char *)realloc(path, *path_length += 10);
      if (temp_path) {
        path = temp_path;
      } else {
        free(path);
      }
    }
  }
}

void read_str_from_stdin(char *str, int *str_length) {
  char *temp_str;
  char c;
  int index_in_str = 0;
  while (((c = getchar()) != '\n') && c != 0) {
    str[index_in_str] = c;
    index_in_str++;
    if (index_in_str == *str_length - 1) {
      temp_str = (char *)realloc(str, *str_length += 10);
      if (temp_str) {
        str = temp_str;
      } else {
        free(str);
      }
    }
  }
}

void out(char *path, int *path_length) {
  for (int i = 0; i < *path_length; ++i) {
    printf("c: %c, i: %d\n", path[i], i);
  }
}

int read_file(char *path) {
  int result = 1;
  char ch;
  int counter = 0;
  FILE *file;
  file = fopen(path, "r");
  if (file) {
#ifdef LOG
    logcat(file, "FILE OPENED");
#endif
    while (!feof(file) && ch != EOF) {
      ch = fgetc(file);
      if (ch != EOF)
        printf("%c", ch);
      counter++;
    }
  } else {
    result = 0;
  }
  if ((counter == 1) || (fclose(file) == EOF)) {
    printf("n/a");
  }
  printf("\n");
  return result;
}

void add_to_file(char *path, int file_was_read) {
  int s_length = 10;
  int *str_length = &s_length;
  char *str = (char *)malloc(*str_length * sizeof(char *));
  read_str_from_stdin(str, str_length);
  if (file_was_read) {
    FILE *file;
    file = fopen(path, "r");
    if (file) {
      fclose(file);
      file = fopen(path, "a");
      if (file) {
        fputs("\n", file);
        fputs(str, file);
        fclose(file);
      } else {
        printf("n/a");
      }
    } else {
      printf("n/a");
    }
  }
  free(str);
}

void cezar_main(int step) {
  int final_result = 1;
  int temp_result = 1;
  char path_m1[50] = "ai_modules/m1.c";
  char path_m1_h[50] = "ai_modules/m1.h";
  char path_m2[50] = "ai_modules/m2.c";
  char path_m2_h[50] = "ai_modules/m2.h";
  temp_result = cezar_encrypt_in_out(step, path_m1);
  if (!temp_result)
    final_result = 0;
  temp_result = clear_file(path_m1_h);
  if (!temp_result)
    final_result = 0;
  temp_result = cezar_encrypt_in_out(step, path_m2);
  if (!temp_result)
    final_result = 0;
  temp_result = clear_file(path_m2_h);
  if (!temp_result)
    final_result = 0;
  if (!final_result)
    printf("n/a");
}

int clear_file(char *path) {
  int error_in_work_with_file_flag = 1;
  FILE *file;
  file = fopen(path, "w");
  if (file)
    fclose(file);
  else
    error_in_work_with_file_flag = 0;
  return error_in_work_with_file_flag;
}

int cezar_encrypt_in_out(int n, char *path) {
  int result = 1, error_in_memory_allocation_flag = 1,
      error_in_work_with_file_flag = 1, b_size = 10, i_in_buf = 0;
  FILE *file;
  char *buf;
  int *buf_size = &b_size, *index_in_buf = &i_in_buf;
  char ch;
  buf = (char *)malloc(b_size * sizeof(char));
  if (!buf)
    error_in_memory_allocation_flag = 0;
  file = fopen(path, "r");
  if (!file)
    error_in_work_with_file_flag = 0;
  if (error_in_memory_allocation_flag && error_in_work_with_file_flag) {
    while (!feof(file)) {
      ch = fgetc(file);
      if (ch != EOF) {
        array_from_file(buf, buf_size, index_in_buf, cezar_encrypt(ch, n));
      }
    }
    if (fclose(file) == EOF) {
      error_in_work_with_file_flag = 0;
    }
  }
  if (error_in_work_with_file_flag) {
    file = fopen(path, "w");
    if (file) {
      for (int i = 0; i < *index_in_buf; ++i) {
        fputc(buf[i], file);
      }
    } else {
      error_in_work_with_file_flag = 0;
    }
  }
  fclose(file);
  if (error_in_memory_allocation_flag)
    free(buf);
  if (!error_in_work_with_file_flag || !error_in_memory_allocation_flag)
    result = 0;
  return result;
}

char cezar_encrypt(char ch, int n) {
  if (ch >= 'A' && ch <= 'Z') {
    ch = ch + n % 26;
    if (ch > 'Z') {
      ch = 'A' + (ch - 'Z') - 1;
    }
  } else if (ch >= 'a' && ch <= 'z') {
    ch = ch + n % 26;
    if (ch > 'z') {
      ch = 'a' + (ch - 'z') - 1;
    }
  } else if (ch >= '0' && ch <= '9') {
    ch = ch + n % 10;
    if (ch > '9') {
      ch = '1' + (ch - '9') - 1;
    }
  }
  return ch;
}

void array_from_file(char *buf, int *buf_size, int *index_in_buf, char ch) {
  char *temp_str;
  buf[*index_in_buf] = ch;
  *index_in_buf += 1;
  if (*index_in_buf == *buf_size - 2) {
    temp_str = (char *)realloc(buf, *buf_size += 10);
    if (temp_str)
      buf = temp_str;
    else
      free(buf);
  }
}
