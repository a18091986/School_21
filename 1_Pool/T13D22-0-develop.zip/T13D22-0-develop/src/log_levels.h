#ifndef SRC_LOG_LEVELS_H_
#define SRC_LOG_LEVELS_H_

char *log_level[] = {
    "DEBUG",
    "TRACE",
    "INFO",
    "WARNING",
    "ERROR"
};

enum log_level_name { debug, trace, info, warning, error};

#endif  // SRC_LOG_LEVELS_H_
