#include "log_levels.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

FILE *log_init(char *filename) {
  int hours, minutes, seconds;
  time_t now;
  time(&now);
  struct tm *local = localtime(&now);
  hours = local->tm_hour;
  minutes = local->tm_min;
  seconds = local->tm_sec;
  FILE *file;
  file = fopen(filename, "a+");
  if (file) {
    fputs(log_level[info], file);
    fprintf(file, " %02d:%02d:%02d ", hours, minutes, seconds);
    fprintf(file, "Main programm started, start logging\n");
  }
  return file;
}

int logcat(FILE *log_file, char *message) {
  int hours, minutes, seconds;
  time_t now;
  time(&now);
  struct tm *local = localtime(&now);
  hours = local->tm_hour;
  minutes = local->tm_min;
  seconds = local->tm_sec;
  fputs(log_level[debug], log_file);
  fprintf(log_file, " %02d:%02d:%02d ", hours, minutes, seconds);
  fprintf(log_file, message);
  fprintf(log_file, "\n");
  return 0;
}

int log_close(FILE *log_file) {
  int hours, minutes, seconds;
  time_t now;
  time(&now);
  struct tm *local = localtime(&now);
  hours = local->tm_hour;
  minutes = local->tm_min;
  seconds = local->tm_sec;
  fputs(log_level[info], log_file);
  fprintf(log_file, " %02d:%02d:%02d ", hours, minutes, seconds);
  fprintf(log_file, "Main programm closed, stop logging\n");
  fclose(log_file);
  return 0;
}
