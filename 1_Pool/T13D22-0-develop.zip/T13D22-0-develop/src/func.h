#include <stdio.h>

#ifndef SRC_FUNC_H_
#define SRC_FUNC_H_

void read_path(char *path, int *path_length);
void out(char *path, int *path_length);
void menu(char *path, int *path_length);
int read_file(char *path);
void add_to_file(char *path, int file_was_read);
void read_str_from_stdin(char *str, int *str_length);
int cezar_encrypt_in_out(int n, char *path);
char cezar_encrypt(char ch, int n);
void array_from_file(char *buf, int *buf_size, int *index_in_buf, char ch);
int clear_file(char *path);
void cezar_main(int step);

#endif  // SRC_FUNC_H_
