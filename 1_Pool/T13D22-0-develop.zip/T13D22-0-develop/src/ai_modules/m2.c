#jodmvef "n3.i"


wpje n3_g2()
{
    qsjoug("UFTU N3");
}

