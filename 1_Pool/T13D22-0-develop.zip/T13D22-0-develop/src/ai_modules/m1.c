#jodmvef "n2.i"


wpje n2_g2()
{
    qsjoug("UFTU N2");
}
