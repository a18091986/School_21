#include "func.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  int p_length = 10;
  int *path_length = &p_length;
  char *path = (char *)malloc(*path_length * sizeof(char *));
  if (path) {
    menu(path, path_length);
    free(path);
  } else {
    printf("n/a\n");
  }
  return 0;
}
