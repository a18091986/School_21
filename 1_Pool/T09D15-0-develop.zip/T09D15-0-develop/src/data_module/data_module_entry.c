#include "../data_libs/data_io.h"
#include "data_process.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  double *data;
  int n;
  int check_error = 1;
  if ((scanf("%d", &n) == 1) && (n > 0)) {
    data = (double *)calloc(n, sizeof(double));
    if (!data) {
      printf("ERROR");
    } else {
      input(data, n, &check_error);
      if (check_error) {
        if (normalization(data, n))
          output(data, n);
        else
          printf("ERROR");
      } else {
        printf("ERROR");
      }
    }
    free(data);
  } else {
    printf("ERROR");
  }
  return 0;
}
