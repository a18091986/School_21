#ifndef SRC_DATA_LIBS_DATA_IO_H_
#define SRC_DATA_LIBS_DATA_IO_H_

void input(double *data, int n, int *check_error);
void output(double *data, int n);

#endif  // SRC_DATA_LIBS_DATA_IO_H_
