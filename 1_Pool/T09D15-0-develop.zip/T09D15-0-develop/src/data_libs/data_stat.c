#include "data_stat.h"

double max(double *data, int n);
double min(double *data, int n);
double mean(double *data, int n);
double variance(double *data, int n);

double max(double *data, int n) {
  double max = data[0];
  for (int i = 0; i < n; i++) {
    if (data[i] > max)
      max = data[i];
  }

  return max;
}

double min(double *data, int n) {
  double min = data[0];
  for (int i = 0; i < n; i++) {
    if (data[i] < min)
      min = data[i];
  }

  return min;
}

double mean(double *data, int n) {
  double sum = 0;
  for (int i = 0; i < n; ++i) {
    sum += data[i] / n;
  }
  return sum;
}

double variance(double *data, int n) {
  int N = n;
  double b[N];
  for (double *p = data; p < &data[n]; p++) {
    b[p - data] = *p * *p;
  }
  double mean_val = mean(data, n);
  double mean_val_pow_2 = mean(b, n);
  return (mean_val_pow_2 - mean_val * mean_val);
}
