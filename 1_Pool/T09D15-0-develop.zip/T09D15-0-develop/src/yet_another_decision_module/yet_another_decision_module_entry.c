#include "../data_libs/data_io.h"
#include "decision.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  double *data;
  int n;
  int check_error = 1;
  if ((scanf("%d", &n) == 1) && (n > 0)) {
    data = (double *)calloc(n, sizeof(double));
    if (!data) {
      printf("ERROR");
    } else {
      input(data, n, &check_error);
      if (check_error) {
        if (make_decision(data, n)) {
          printf("YES");
        } else {
          printf("NO");
        }
      } else {
        printf("ERROR");
      }
      free(data);
    }
  } else {
    printf("ERROR");
  }
  return 0;
}
