#!/bin/bash 

killall bash ai_door_management_module.sh 
