#!/bin/bash

cd ai_help
chmod +x keygen.sh unifier.sh
sh keygen.sh
rm key/file*
sh unifier.sh
