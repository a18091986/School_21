#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
void squaring(int *a, int n);

int main() {
  int n, data[NMAX], result;
  result = input(data, &n);
  if (result == 1) {
    squaring(data, n);
    output(data, n);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *a, int *n) {
  int result = 1;
  if ((scanf("%d", n) != 1) || (*n <= 0) || (*n > NMAX)) {
    result = -1;
  } else {
    int temp;
    for (int *p = a; (p - a) < *n; p++) {
      if (scanf("%d", &temp) == 1) {
        *p = temp;
      } else {
        result = -1;
      }
    }
  }
  return result;
}

void output(int *a, int n) {
  for (int *p = a; p < &a[n]; p++) {
    if (p < &a[n - 1]) {
      printf("%d ", *p);
    } else {
      printf("%d", *p);
    }
  }
}

void squaring(int *a, int n) {
  for (int *p = a; p < &a[n]; p++) {
    a[p - a] = *p * *p;
  }
}
