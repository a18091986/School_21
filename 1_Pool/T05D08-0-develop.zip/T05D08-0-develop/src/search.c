/*
    Search module for the desired value from data array.
    Returned value must be:
        - "even"
        - ">= mean"
        - "<= mean + 3 * sqrt(variance)"
        - "!= 0"

        OR

        0
*/
#include <math.h>
#include <stdio.h>
#define NMAX 30

int input(int *a, int *n);
int max(int *a, int n);
int min(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);
void output_result(double mean_v, double variance_v, int *a, int n);
int main() {
  int n, data[NMAX], result;
  result = input(data, &n);
  if (result == 1) {
    output_result(mean(data, n), variance(data, n), data, n);
  } else {
    printf("n/a");
  }
  return 0;
}

int input(int *a, int *n) {
  int result = 1;
  if ((scanf("%d", n) != 1) || (*n <= 0) || (*n > NMAX)) {
    result = -1;
  } else {
    int temp;
    for (int *p = a; (p - a) < *n; p++) {
      if (scanf("%d", &temp) == 1) {
        *p = temp;
      } else {
        result = -1;
      }
    }
  }
  return result;
}

int max(int *a, int n) {
  int cur_max = *a;
  for (int *p = a; p < &a[n]; p++) {
    if (*p >= cur_max) {
      cur_max = *p;
    }
  }
  return cur_max;
}

int min(int *a, int n) {
  int cur_min = *a;
  for (int *p = a; p < &a[n]; p++) {
    if (*p <= cur_min) {
      cur_min = *p;
    }
  }
  return cur_min;
}

double mean(int *a, int n) {
  double result = 0;
  for (int *p = a; p < &a[n]; p++) {
    result += (double)*p / n;
  }
  return result;
}

double variance(int *a, int n) {
  int N = n;
  int b[N];
  for (int *p = a; p < &a[n]; p++) {
    b[p - a] = *p * *p;
  }
  double mean_val = mean(a, n);
  double mean_val_pow_2 = mean(b, n);
  return (mean_val_pow_2 - mean_val * mean_val);
}

void output_result(double mean_v, double variance_v, int *a, int n) {
  int result = 0;
  double sigma = sqrt(variance_v);
  for (int *p = a; p < &a[n]; p++) {
    if ((*p % 2 == 0) && (*p > mean_v) && (*p >= mean_v - 3 * sigma) &&
        (*p <= mean_v + 3 * sigma) && (*p != 0)) {
      if (result == 0) {
        result = *p;
      }
    }
  }
  printf("%d", result);
}
