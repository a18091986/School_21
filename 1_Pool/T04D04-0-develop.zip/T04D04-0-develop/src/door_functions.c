#include <math.h>
#include <stdio.h>

double agn(double x) { return 1 / (1 + pow(x, 2)); }

double lemn(double x) { return sqrt(sqrt(1 + 4 * pow(x, 2)) - pow(x, 2) - 1); }

double gip(double x) { return 1 / pow(x, 2); }

int main(void) {
  for (double x = (-1) * M_PI; x <= M_PI; x += 2 * M_PI / 41.) {
      if (x < M_PI - M_PI / 41.) {
        printf("%.7lf | ", x);
        agn(x) != agn(x) ? printf("- | ") : printf("%.7lf |", agn(x));
        lemn(x) != lemn(x) ? printf(" - | ") : printf(" %.7lf | ", lemn(x));
        gip(x) != gip(x) ? printf("- |\n") : printf("%.7lf\n", gip(x));
      } else {
          printf("%.7lf | ", x);
          agn(x) != agn(x) ? printf("- |") : printf("%.7lf | ", agn(x));
          lemn(x) != lemn(x) ? printf("- |") : printf(" %.7lf | ", lemn(x));
          gip(x) != gip(x) ? printf("- |") : printf(" %.7lf", gip(x));
  }
  }
  return 0;
}
