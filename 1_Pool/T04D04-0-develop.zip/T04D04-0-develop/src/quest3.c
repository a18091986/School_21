#include <stdio.h>

int fib(int N) {
  if (N == 0)
      return 0;
  if (N == 1 || N == 2)
      return 1;
  return fib(N-1) + fib(N-2);
}

int main() {
  int N;
  if ((scanf("%d", &N) != 1) || getchar() != 10 || N < 0)
    printf("n/a");
  else
    printf("%d", fib(N));
  return 0;
}
