#include <stdio.h>

int division_reminder(int numerator, int denominator) {
  while (numerator - denominator >= 0) {
    numerator = numerator - denominator;
  }
  return numerator;
}

int is_simple(int number) {  // простое ли число
  int count = 0;
  for (int i = 1; i <= number;
       i++) {  // делим на все числа от 1 до введенного числа
  if (division_reminder(number, i) == 0) {
    count += 1;
    }
  }
  if (count > 2)
    return 1;
  return 0;
}

int main(void) {
  int max_simple;
  int x;
    if ((scanf("%d", &x) != 1) || getchar() != 10 || x == 1 || x == 0 || x == -1) {
      printf("n/a");
    } else {
  (x < 0)?(x = x * -1):(x);
  for (int i = 1; i <= x; i++) {  // делим на все числа от 1 до введенного числа
    if (division_reminder(x, i) == 0) {
      if (is_simple(i) == 0) {
        max_simple = i;
      }
    }
  }
  printf("%d", max_simple);
  }
  return 0;
}
