#include <stdio.h>

double circle(float x, float y);

int main() {
    float x, y;
    if ((scanf("%f %f", &x, &y) != 2) || getchar() != 10) {
        printf("n/a");
        return 1;
    }
    double res = circle(x, y);
    if (res < 25.0)
        printf("GOTCHA");
    else
        printf("MISS");
    return 0;
}

double circle(float x, float y) { return (x * x + y * y); }
