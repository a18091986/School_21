#include <stdio.h>

int main() {
    int in_1, in_2;
    if ((scanf("%d %d", &in_1, &in_2) != 2) || getchar() != 10) {
        printf("n/a");
        return 1;
    }
    if (in_1 >= in_2) {
        printf("%d", in_1);
    } else {
        printf("%d", in_2);
    }
    return 0;
}
