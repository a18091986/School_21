#include <stdio.h>

int main(void) {
    int name;
    if ((scanf("%d", &name) != 1) || getchar() != 10) {
        printf("Введено не целое число");
        return 0;
    }
    printf("Hello, %d!", name);
    return 0;
}
