#include <stdio.h>

int sum(int a, int b);
int sub(int a, int b);
int div(int a, int b);
int mul(int a, int b);

int main() {
    int x1, x2;
    if ((scanf("%d %d", &x1, &x2) != 2) || getchar() != 10) {
        printf("n/a n/a n/a n/a");
        return 1;
    }
    if (x2 == 0) {
        printf("%d %d %d n/a", sum(x1, x2), sub(x1, x2), mul(x1, x2));
        return 0;
    }
    printf("%d %d %d %d", sum(x1, x2), sub(x1, x2), mul(x1, x2), div(x1, x2));
    return 0;
}
int sum(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }
int div(int a, int b) { return a / b; }
int mul(int a, int b) { return a * b; }
